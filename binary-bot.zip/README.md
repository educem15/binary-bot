# Binary Options Trading Signal Generator

An advanced trading signal generator for Binary Options trading, featuring technical analysis, machine learning, and real-time data integration.

## Features

- Real-time forex data from multiple sources (Alpha Vantage, Finnhub, Fixer)
- Advanced technical analysis with multiple indicators
- Machine learning models (Random Forest and LSTM) for signal prediction
- Signal strength grading (1-5 scale)
- Support for multiple timeframes (1min, 3min, 5min)
- Self-learning capability through trading results feedback
- REST API for easy integration
- Comprehensive statistics and performance tracking

## Technical Indicators Used

1. Moving Averages (SMA, EMA)
2. MACD (Moving Average Convergence Divergence)
3. RSI (Relative Strength Index)
4. Bollinger Bands
5. Stochastic Oscillator
6. ADX (Average Directional Index)
7. Ichimoku Cloud
8. OBV (On-Balance Volume)
9. Momentum
10. CCI (Commodity Channel Index)

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd binary-options-signals
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up your API keys in `config/.env`:
```
FIXER_API_KEY=your_fixer_api_key
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_api_key
FINNHUB_API_KEY=your_finnhub_api_key
```

## Running the Application

1. Start the API server:
```bash
python -m app.api.main
```

The API will be available at `http://localhost:8000`

## API Endpoints

- `GET /`: Health check
- `POST /signals`: Get trading signals with custom parameters
- `GET /best_signals`: Get strongest current signals
- `POST /update_results`: Update models with trading results
- `GET /statistics`: Get signal generation statistics
- `POST /save_models`: Save current model state
- `POST /load_models`: Load saved model state

### Example API Usage

1. Get trading signals:
```bash
curl -X POST "http://localhost:8000/signals" \
     -H "Content-Type: application/json" \
     -d '{"timeframes": ["1min", "5min"], "pairs": ["EUR/USD", "GBP/USD"], "min_strength": 3.0}'
```

2. Get best signals:
```bash
curl "http://localhost:8000/best_signals?min_strength=4.0"
```

3. Update with trading results:
```bash
curl -X POST "http://localhost:8000/update_results" \
     -H "Content-Type: application/json" \
     -d '[{
       "pair": "EUR/USD",
       "timeframe": "1min",
       "timestamp": "2024-01-01T12:00:00",
       "direction": "CALL",
       "entry_price": 1.1000,
       "exit_price": 1.1010,
       "success": true,
       "profit_loss": 10.0
     }]'
```

## Signal Strength Interpretation

- 5.0: Very strong signal with high probability of success
- 4.0-4.9: Strong signal
- 3.0-3.9: Moderate signal
- 2.0-2.9: Weak signal
- 1.0-1.9: Very weak signal (not recommended for trading)

## Model Training and Updates

The system uses two types of models:
1. Random Forest for pattern recognition
2. LSTM for time series prediction

Models are automatically updated when you submit trading results through the API. This allows the system to learn from successful and unsuccessful trades.

## Best Practices

1. Always wait for signals with strength >= 3.0
2. Use multiple timeframe analysis for confirmation
3. Submit trading results regularly to improve model accuracy
4. Monitor signal statistics to identify most profitable pairs/timeframes
5. Use proper money management (recommended: max 2-3% risk per trade)
6. Consider market conditions and news events
7. Backtest strategies before live trading

## Contributing

Contributions are welcome! Please feel free to submit pull requests.

## License

MIT License

## Disclaimer

This software is for educational purposes only. Trading Binary Options carries significant risks. Always do your own research and never trade with money you cannot afford to lose. 